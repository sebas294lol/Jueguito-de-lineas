package com.trayectoriadetiro.doscuatro;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.Context;
import android.os.SystemClock;
import java.util.Random;

public class MainActivity extends Activity {
    private GameView game;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        game = new GameView(this);
        setContentView(game);
    }
    @Override protected void onResume(){ super.onResume(); if(game!=null) game.startLoop(); }
    @Override protected void onPause(){ if(game!=null) game.stopLoop(); super.onPause(); }

    public static final class GameView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final Random rng = new Random();

        private boolean running;
        private long lastNanos;
        private int mode = 0; // menu
        private int difficulty = 1;

        private float power = 7f, curve = 0f, height = 45f;
        private float ballX, ballY, startX, startY, targetX, targetY;
        private float shotT, shotDuration = 1f;
        private boolean shooting, shotResolved;
        private float keeperX, keeperY, keeperTX, keeperTY;
        private float keeperVX, keeperVY;
        private boolean diving;
        private float diveT;
        private float playerT;
        private float goalPulse;

        private int goals, saves, shots, streak, record;
        private int challengeGoal = 5, challengeProgress;
        private float botTimer;

        private final RectF goal = new RectF();
        private final RectF field = new RectF();

        public GameView(Context c) {
            super(c);
            setFocusable(true);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            text.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            reset();
        }

        public void startLoop() {
            if(running) return;
            running = true;
            lastNanos = System.nanoTime();
            removeCallbacks(loop);
            postOnAnimation(loop);
        }
        public void stopLoop() {
            running = false;
            removeCallbacks(loop);
        }
        private final Runnable loop = new Runnable() {
            @Override public void run() {
                if(!running) return;
                long now = System.nanoTime();
                float dt = (now-lastNanos)/1_000_000_000f;
                lastNanos = now;
                if(dt > .05f) dt=.05f;
                update(dt);
                invalidate();
                postOnAnimation(this);
            }
        };

        private void update(float dt) {
            if(goalPulse>0) goalPulse=Math.max(0,goalPulse-dt*3f);
            if(playerT<1) playerT=Math.min(1,playerT+dt*3.8f);

            if(mode==2 && !shooting) {
                botTimer += dt;
                if(botTimer>=1.0f) { botTimer=0; botShoot(); }
            }

            if(shooting) {
                shotT += dt/shotDuration;
                if(shotT>1) shotT=1;
                updateBall(shotT);
                updateKeeper(dt);
                if(shotT>=1 && !shotResolved) resolveShot();
            }

            if(diving) {
                diveT += dt/.42f;
                if(diveT>=1) { diveT=1; diving=false; }
            }
        }

        private void updateBall(float t) {
            float smooth=t*t*(3-2*t);
            float x=startX+(targetX-startX)*smooth;
            float y=startY+(targetY-startY)*smooth;
            float curveOffset=(float)Math.sin(Math.PI*t)*curve*3.0f;
            float lift=(float)Math.sin(Math.PI*t)*(height/100f)*250f;
            ballX=x+curveOffset;
            ballY=y-lift;
        }

        private void updateKeeper(float dt) {
            float speed = difficulty==0?3.0f:(difficulty==1?4.5f:6.5f);
            keeperVX += (keeperTX-keeperX)*speed*dt;
            keeperVY += (keeperTY-keeperY)*speed*dt;
            keeperVX *= .78f; keeperVY *= .78f;
            keeperX += keeperVX; keeperY += keeperVY;
            clampKeeper();
        }

        private void clampKeeper() {
            float pad=18;
            keeperX=Math.max(goal.left+pad,Math.min(goal.right-pad,keeperX));
            keeperY=Math.max(goal.top+pad,Math.min(goal.bottom-pad,keeperY));
        }

        private void chooseKeeperTarget() {
            float err=difficulty==0?55:(difficulty==1?30:17);
            keeperTX=targetX + (rng.nextFloat()*2-1)*err;
            keeperTY=targetY + (rng.nextFloat()*2-1)*err;
            clampTarget();
        }

        private void clampTarget() {
            float pad=12;
            keeperTX=Math.max(goal.left+pad,Math.min(goal.right-pad,keeperTX));
            keeperTY=Math.max(goal.top+pad,Math.min(goal.bottom-pad,keeperTY));
        }

        private void shoot(float tx,float ty) {
            if(shooting) return;
            shots++;
            shooting=true; shotResolved=false; shotT=0;
            playerT=0; targetX=tx; targetY=ty;
            startX=getWidth()*.16f; startY=getHeight()*.60f;
            ballX=startX; ballY=startY;
            shotDuration=Math.max(.55f,1.48f-power*.078f);
            chooseKeeperTarget();
        }

        private void botShoot() {
            float tx=goal.left+goal.width()*(.12f+.76f*rng.nextFloat());
            float ty=goal.top+goal.height()*(.10f+.80f*rng.nextFloat());
            if(difficulty==0) {
                power=4+rng.nextFloat()*2; curve=-8+rng.nextFloat()*16; height=25+rng.nextFloat()*25;
            } else if(difficulty==1) {
                power=6+rng.nextFloat()*2.5f; curve=-18+rng.nextFloat()*36; height=30+rng.nextFloat()*40;
            } else {
                power=7.5f+rng.nextFloat()*2.5f; curve=-30+rng.nextFloat()*60; height=20+rng.nextFloat()*65;
            }
            shoot(tx,ty);
        }

        private boolean insideGoal() {
            // El balón debe estar entre postes y debajo del larguero.
            return ballX>=goal.left+7 && ballX<=goal.right-7 &&
                   ballY>=goal.top+7 && ballY<=goal.bottom-7;
        }

        private boolean saved() {
            float dx=ballX-keeperX, dy=ballY-keeperY;
            float r=difficulty==0?52:(difficulty==1?40:31);
            return dx*dx+dy*dy <= r*r;
        }

        private void resolveShot() {
            shotResolved=true; shooting=false;
            boolean goal=insideGoal();
            boolean save=saved();
            if(goal && !save) {
                goals++; streak++; record=Math.max(record,streak); goalPulse=1;
                if(mode==1) challengeProgress++;
            } else {
                if(save) saves++;
                streak=0;
            }
            if(mode==1 && challengeProgress>=challengeGoal) {
                challengeGoal=Math.min(20,challengeGoal+2);
                challengeProgress=0;
            }
        }

        private void reset() {
            shooting=false; shotResolved=false; shots=goals=saves=streak=0;
            challengeGoal=5; challengeProgress=0; botTimer=0;
            power=7; curve=0; height=45;
            startX=getWidth()*.16f; startY=getHeight()*.60f;
            ballX=startX; ballY=startY;
            targetX=getWidth()*.82f; targetY=getHeight()*.50f;
            keeperX=getWidth()*.81f; keeperY=getHeight()*.50f;
            keeperTX=keeperX; keeperTY=keeperY;
        }

        @Override protected void onSizeChanged(int w,int h,int ow,int oh) {
            field.set(20,20,w-20,h-20);
            goal.set(w*.68f,h*.24f,w*.94f,h*.73f);
            if(!shooting) {
                startX=w*.16f; startY=h*.60f;
                ballX=startX; ballY=startY;
                targetX=w*.82f; targetY=h*.50f;
                keeperX=w*.81f; keeperY=h*.50f;
                keeperTX=keeperX; keeperTY=keeperY;
            }
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            if(mode==0) drawMenu(c); else drawGame(c);
        }

        private void drawMenu(Canvas c) {
            c.drawColor(Color.rgb(15,30,20));
            text.setTextAlign(Paint.Align.CENTER); text.setColor(Color.WHITE);
            text.setTextSize(34);
            c.drawText("⚽ TRAYECTORIA DE TIROS 2.4",getWidth()/2f,70,text);
            button(c,"🎯 NORMAL",120);
            button(c,"🏆 RETOS",210);
            button(c,"🧤 MODO PORTERO",300);
            button(c,"🥅 PENALES",390);
            button(c,"🎯 TIROS LIBRES",480);
            button(c,"👤 1 VS 1",570);
        }

        private void button(Canvas c,String s,float y) {
            p.setColor(Color.rgb(32,132,67));
            c.drawRoundRect(getWidth()*.20f,y,getWidth()*.80f,y+62,18,18,p);
            text.setTextSize(21); text.setColor(Color.WHITE);
            c.drawText(s,getWidth()/2f,y+40,text);
        }

        private void drawGame(Canvas c) {
            drawField(c); drawGoal(c); drawTrajectory(c); drawPlayer(c);
            drawKeeper(c); drawBall(c); drawHud(c);
        }

        private void drawField(Canvas c) {
            c.drawColor(Color.rgb(42,150,69));
            p.setColor(Color.rgb(34,126,57));
            for(int i=0;i<8;i++) {
                float y=20+i*(getHeight()-40)/8f;
                c.drawRect(20,y,getWidth()-20,y+18,p);
            }
            stroke.setColor(Color.WHITE); stroke.setStrokeWidth(4);
            c.drawRect(field,stroke);
            c.drawLine(getWidth()*.50f,20,getWidth()*.50f,getHeight()-20,stroke);
            c.drawCircle(getWidth()*.50f,getHeight()/2f,75,stroke);
        }

        private void drawGoal(Canvas c) {
            float pulse=(float)Math.sin(goalPulse*Math.PI)*7;
            stroke.setColor(Color.WHITE); stroke.setStrokeWidth(8);
            c.drawRect(goal.left,goal.top+pulse,goal.right,goal.bottom+pulse,stroke);
            stroke.setStrokeWidth(2);
            p.setColor(Color.argb(55,255,255,255));
            for(int i=1;i<6;i++) {
                float x=goal.left+i*goal.width()/6f;
                c.drawRect(x,goal.top,x+1,goal.bottom,p);
            }
        }

        private void drawTrajectory(Canvas c) {
            if(!shooting && !shotResolved) return;
            path.reset(); path.moveTo(startX,startY);
            for(int i=1;i<=36;i++) {
                float t=i/36f;
                float sm=t*t*(3-2*t);
                float x=startX+(targetX-startX)*sm;
                float y=startY+(targetY-startY)*sm;
                x+=(float)Math.sin(Math.PI*t)*curve*3;
                y-=(float)Math.sin(Math.PI*t)*(height/100f)*250;
                path.lineTo(x,y);
            }
            stroke.setColor(Color.rgb(255,235,65)); stroke.setStrokeWidth(4);
            c.drawPath(path,stroke);
        }

        private void drawPlayer(Canvas c) {
            float x=getWidth()*.13f, y=getHeight()*.60f;
            float kick=playerT<1?(float)Math.sin(playerT*Math.PI)*24:0;
            p.setColor(Color.WHITE);
            c.drawCircle(x,y-54,16,p); c.drawRect(x-17,y-38,x+17,y+12,p);
            stroke.setColor(Color.WHITE); stroke.setStrokeWidth(8);
            c.drawLine(x,y+10,x-18-kick,y+55,stroke);
            c.drawLine(x,y+10,x+18+kick,y+55,stroke);
        }

        private void drawKeeper(Canvas c) {
            float x=keeperX,y=keeperY;
            p.setColor(Color.rgb(35,92,185));
            c.drawCircle(x,y-28,15,p); c.drawRect(x-17,y-13,x+17,y+30,p);
            float reach=diving?45:25;
            stroke.setColor(Color.WHITE); stroke.setStrokeWidth(7);
            c.drawLine(x,y,x-reach,y-18,stroke); c.drawLine(x,y,x+reach,y-18,stroke);
            c.drawLine(x,y+30,x-13,y+60,stroke); c.drawLine(x,y+30,x+13,y+60,stroke);
        }

        private void drawBall(Canvas c) {
            p.setColor(Color.WHITE); c.drawCircle(ballX,ballY,12,p);
            p.setColor(Color.BLACK); c.drawCircle(ballX,ballY,3,p);
        }

        private void drawHud(Canvas c) {
            text.setTextAlign(Paint.Align.LEFT); text.setTextSize(18); text.setColor(Color.WHITE);
            c.drawText("Goles: "+goals,30,38,text);
            c.drawText("Atajadas: "+saves,30,62,text);
            c.drawText("Racha: "+streak+"  Récord: "+record,30,86,text);
            c.drawText("Potencia: "+Math.round(power)+"  Curva: "+Math.round(curve)+"  Altura: "+Math.round(height),30,getHeight()-22,text);
            text.setTextAlign(Paint.Align.RIGHT);
            String m=mode==2?"MODO PORTERO":mode==1?"RETOS":"NORMAL";
            c.drawText(m,getWidth()-25,38,text);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float x=e.getX(), y=e.getY();
            if(e.getAction()==MotionEvent.ACTION_MOVE && mode==2) {
                moveKeeper(x,y); return true;
            }
            if(e.getAction()!=MotionEvent.ACTION_DOWN) return true;

            if(mode==0) {
                if(y>=120&&y<182){mode=3;reset();}
                else if(y>=210&&y<272){mode=1;reset();}
                else if(y>=300&&y<362){mode=2;reset();}
                else if(y>=390&&y<452){mode=3;reset();}
                else if(y>=480&&y<542){mode=4;reset();}
                else if(y>=570&&y<632){mode=5;reset();}
                return true;
            }

            if(x<110 && y<100) { mode=0; reset(); return true; }

            if(mode==2) {
                if(x>goal.left*.85f) {
                    moveKeeper(x,y);
                    diving=true; diveT=0;
                }
                return true;
            }

            if(!shooting) {
                if(x>getWidth()*.52f) { targetX=x; targetY=y; return true; }
                if(x<getWidth()*.52f) { shoot(targetX,targetY); return true; }
            }
            return true;
        }

        private void moveKeeper(float x,float y) {
            keeperX=Math.max(goal.left+10,Math.min(goal.right-10,x));
            keeperY=Math.max(goal.top+10,Math.min(goal.bottom-10,y));
            keeperTX=keeperX; keeperTY=keeperY;
        }
    }
}
